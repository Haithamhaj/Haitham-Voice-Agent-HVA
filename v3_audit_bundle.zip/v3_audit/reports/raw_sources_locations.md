# Raw Source Data Locations

- **File:** `/Users/haitham/development/Haitham Voice Agent (HVA)/data/haithm_corpus_raw_gpt_2025-12-11.jsonl`
- **File:** `/Users/haitham/development/Haitham Voice Agent (HVA)/data/haithm_corpus_whatsapp_haithm_only.jsonl`

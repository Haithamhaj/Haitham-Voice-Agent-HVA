# HVA Runtime Flow Analysis

## 1. Schema Injection
- Location: `OllamaOrchestrator._classify_with_ollama`
- The System Prompt is injected with strict JSON schema instructions before every request.

## 2. Retries
- Logic: `OllamaOrchestrator.classify_request`
- Retry Count: 2 attempts on JSON parse failure.

## 3. Fallback Trigger
- Location: `Dispatcher.dispatch`
- If `OllamaOrchestrator` returns `None` or fails after retries, the Dispatcher falls back to `LLMRouter` (Cloud-based).

## 4. Error Handling
- Errors are caught in `Dispatcher`, logged, and returned as a safe error message to the user.
